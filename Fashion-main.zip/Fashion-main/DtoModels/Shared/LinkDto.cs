﻿namespace E_Commerce.DtoModels.Shared
{
	public record LinkDto(string Href, string Rel, string Method);
	
}
