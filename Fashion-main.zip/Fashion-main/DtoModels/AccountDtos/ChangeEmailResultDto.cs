﻿namespace E_Commerce.DtoModels.AccountDtos
{
	public class ChangeEmailResultDto
	{
		public string Note { get; set; }
		public string NewEmail { get; set; }
	}
}
