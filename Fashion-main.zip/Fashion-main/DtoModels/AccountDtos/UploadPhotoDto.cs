﻿namespace E_Commerce.DtoModels.AccountDtos
{
	public record UploadPhotoDto(IFormFile image);

}
