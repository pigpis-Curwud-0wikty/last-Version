﻿using System.ComponentModel.DataAnnotations;

namespace E_Commerce.DtoModels.CategoryDtos
{
	public class AddMainImageDto
	{
		public IFormFile Image { get; set; }
	}
}
