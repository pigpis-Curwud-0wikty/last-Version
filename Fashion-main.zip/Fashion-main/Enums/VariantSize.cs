namespace E_Commerce.Enums
{
    public enum VariantSize
    {
        XS,
        S,
        M,
        L,
        XL,
        XXL,
        XXXL
    }

}