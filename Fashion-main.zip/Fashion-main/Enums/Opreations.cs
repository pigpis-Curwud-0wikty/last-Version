﻿namespace E_Commerce.Enums
{
	
	public enum Opreations
	{
		AddOpreation,
		UpdateOpreation,
		DeleteOpreation,
		UndoDeleteOpreation
	}
}
