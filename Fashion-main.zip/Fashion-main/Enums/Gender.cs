namespace E_Commerce.Enums
{
    public enum Gender
    {
        Man,
        Woman,
        Kids,
        Uni
    }
} 