namespace E_Commerce.Enums
{
	public enum PaymentMethod
	{
		Cash = 1,
		Visa = 2,
		Meeza = 3,
		Wallet = 4
	}
} 