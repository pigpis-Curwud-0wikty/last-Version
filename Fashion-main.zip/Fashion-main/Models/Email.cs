﻿namespace E_Commerce.Models
{
	public class Email
	{
		public string Address { get; set; }
		public string Password { get; set; }
		public string Host { get; set; }
		public int Port { get; set; }

	}
}
